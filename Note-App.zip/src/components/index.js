import "./header-bar.js";
import "./note-form.js";
import "./note-list.js";
import "./footer-bar.js";
